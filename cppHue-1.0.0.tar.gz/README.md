# cppHue
a hopfully only to std cpp dependet Philips Hue library for linux esp32 and all others

this is developent state.

Goal is to have a cross platform library for the basic hue featchers
Personal goal is to have a library under the MIT license for Philips Hue with that i can control my light bulbs from an esp32 and that I can unit test from a pc

